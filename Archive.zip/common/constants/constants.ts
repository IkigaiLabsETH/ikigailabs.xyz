export const COLLECTION_METADATA_FIELDS = ['name', 'description', 'image']
