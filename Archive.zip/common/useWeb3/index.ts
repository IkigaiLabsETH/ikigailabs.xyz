export { useWeb3 as default } from './useWeb3'
