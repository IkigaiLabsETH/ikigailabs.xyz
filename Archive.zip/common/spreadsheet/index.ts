export { table } from './spreadsheet'
export type { Table, FieldSet } from 'airtable'
