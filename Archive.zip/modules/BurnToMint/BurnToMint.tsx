import { append, equals, findIndex, isNil, map, prop, propEq } from 'ramda'
import React, { ChangeEvent, FC, useEffect, useState } from 'react'
import { match } from 'ts-pattern'

import { store, useAppDispatch, useAppSelector } from '../../common/redux/store'
import { useWallet } from '../../common/useWallet'
import { Button } from '../Button'
import { burnToMint, checkBalances } from './burnToMint.slice'
import { BURN_TO_MINT } from '../../common/config'
import { selectContractCallStatus, selectTokensWithBalancesForAddress } from '../../common/web3/tokenBalance.slice'
import { collectionTokenApi, selector } from '../Collection/Token/token.api'
import { addOrReplace, mapIndexed } from '../../common/utils/utils'
import { divide } from 'lodash'

interface BurnToMintProps {
  elevenFiftyFiveContractAddress: string
  sevenTwentyOneContractAddress: string
}

export const BurnToMint: FC<BurnToMintProps> = ({ elevenFiftyFiveContractAddress, sevenTwentyOneContractAddress }) => {
  const dispatch = useAppDispatch()
  const { address, connect } = useWallet()
  const tokensWithBalance = useAppSelector(selectTokensWithBalancesForAddress(address))
  const tokenSelector = useAppSelector(selector) as any
  const contractCallStatus = useAppSelector(selectContractCallStatus)
  console.log(contractCallStatus)
  const collection = prop('odessyGenesisCollection')(BURN_TO_MINT)
  const [tokensToBurn, setTokensToBurn] = useState([]) 

  const handleConnect = (event: ChangeEvent<HTMLButtonElement>) => {
    event.preventDefault()
    connect()
  }

  const handleBurnToMint = async (event: ChangeEvent<HTMLButtonElement>) => {
    event.preventDefault()
    dispatch(burnToMint({ address, elevenFiftyFiveContractAddress, sevenTwentyOneContractAddress, tokenId: '0' }))
  }

  const checkEligibility = async (event: ChangeEvent<HTMLButtonElement>) => {
    event.preventDefault()
    dispatch(checkBalances({ address, collection }))
  }

  useEffect(() => {
    console.log(tokensWithBalance)
    if (tokensWithBalance.length > 0) {
      map(({ contract, tokenId }: { contract: string, tokenId: string }) => {
        const { data } = tokenSelector({ contract, tokenId })

        if (data?.token) {
          const tokenData = addOrReplace(tokensToBurn, data.token, 'tokenId')
          setTokensToBurn(tokenData)
        }
      })(tokensWithBalance)
    }
  }, [tokensWithBalance, tokenSelector])

  const tokenList = (
    <div>
      {
        map((tokenToBurn: { tokenId: string }) => (
          <div key={tokenToBurn.tokenId}>
            <p>{tokenToBurn.tokenId}</p>
          </div>
        ))(tokensToBurn)
      }
      {JSON.stringify(tokensToBurn)}
    </div>
  )

  return (
    <div className="flex flex-col relative justify-center items-center lg:min-h-screen bg-white text-black min">
      <div className="lg:w-2/3 p-16">
        <h1 className="boska lg:text-[6rem]">Odyssey Genesis Collection Contract Swap</h1>
        <p className="text-gray-800 text-xl">Swap your Dimitri Artwork</p>
        <div className='flex flex-row w-full'>
          { 
            contractCallStatus === 'succeeded' ? (
              tokensToBurn.length > 0 ? tokenList : 'No eligible tokens found'
            ) : (
              match(address)
                .when(isNil, () => <Button onClick={handleConnect} label="Connect" />)
                .otherwise(() => (
                  <Button onClick={checkEligibility} label="Check eligibility" loading={equals(contractCallStatus, 'pending') ? true : false }/>
                ))
            )
          }
        </div>
      </div>
    </div>
  )
}
