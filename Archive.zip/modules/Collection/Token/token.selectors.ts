import { collectionTokenApi } from './token.api'

export const selectCollectionToken = collectionTokenApi.endpoints.getTokenByContractAndTokenId.select
