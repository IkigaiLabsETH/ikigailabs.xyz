export { FeaturedAuction } from './Featured'
export { reducer as featuredAuctionReducer } from './featured.slice'
