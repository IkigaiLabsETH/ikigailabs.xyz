import { createAction } from '@reduxjs/toolkit'

export const appInit = createAction('app/init')
